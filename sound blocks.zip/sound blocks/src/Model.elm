module Model exposing (..)

import Dict exposing (Dict)


type alias Vec2 =
    { x : Float
    , y : Float
    }


vecAdd : Vec2 -> Vec2 -> Vec2
vecAdd a b =
    { x = a.x + b.x, y = a.y + b.y }


vecScale : Float -> Vec2 -> Vec2
vecScale s v =
    { x = v.x * s, y = v.y * s }


vecSub : Vec2 -> Vec2 -> Vec2
vecSub a b =
    { x = a.x - b.x, y = a.y - b.y }


vecLen : Vec2 -> Float
vecLen v =
    sqrt (v.x * v.x + v.y * v.y)


vecDot : Vec2 -> Vec2 -> Float
vecDot a b =
    a.x * b.x + a.y * b.y


vecNorm : Vec2 -> Vec2
vecNorm v =
    let
        l =
            vecLen v
    in
    if l < 0.0001 then
        { x = 0, y = 0 }

    else
        { x = v.x / l, y = v.y / l }


type alias BodyId =
    Int


type alias Body =
    { id : BodyId
    , pos : Vec2
    , vel : Vec2
    , radius : Float
    , mass : Float
    , restitution : Float
    , label : String
    }


type UiMode
    = DrawMode
    | SelectMode


type alias Cursor =
    { pos : Vec2
    , visible : Bool
    }


type alias Bounds =
    { width : Float
    , height : Float
    }


type alias SimConfig =
    { gravity : Vec2
    , damping : Float
    , tickRateHz : Int
    }


type alias Model =
    { bodies : Dict BodyId Body
    , nextId : BodyId
    , bounds : Bounds
    , sim : SimConfig
    , running : Bool
    , mode : UiMode
    , selected : Maybe BodyId
    , cursor : Cursor
    , announcement : String
    , stepCount : Int
    }


initialModel : Model
initialModel =
    { bodies = Dict.empty
    , nextId = 1
    , bounds = { width = 800, height = 600 }
    , sim =
        { gravity = { x = 0, y = 300 }
        , damping = 0.999
        , tickRateHz = 30
        }
    , running = True
    , mode = DrawMode
    , cursor =
        { pos = { x = 400, y = 200 }
        , visible = True
        }
    , announcement = "Particle Forge ready. Draw mode. Arrow keys move cursor, Enter places a circle, Tab to switch to Select mode."
    , stepCount = 0
    }


makeBody : BodyId -> Vec2 -> Float -> Body
makeBody id pos radius =
    { id = id
    , pos = pos
    , vel = { x = 0, y = 0 }
    , radius = radius
    , mass = radius * radius * 0.01
    , restitution = 0.7
    , label = "Circle " ++ String.fromInt id
    }
