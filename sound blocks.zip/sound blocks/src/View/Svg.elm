module View.Svg exposing (viewWorld)

import Dict
import Html exposing (Html)
import Html.Attributes
import Model exposing (..)
import Svg exposing (..)
import Svg.Attributes as SA
import Svg.Events as SE


type alias ViewMsg =
    Msg


type Msg
    = ClickBody BodyId
    | NoOp


viewWorld : Model -> (Msg -> msg) -> Html msg
viewWorld model toMsg =
    let
        w =
            String.fromFloat model.bounds.width

        h =
            String.fromFloat model.bounds.height
    in
    svg
        [ SA.width w
        , SA.height h
        , SA.viewBox ("0 0 " ++ w ++ " " ++ h)
        , SA.style "background: #0a0a0f; display: block;"
        , Html.Attributes.attribute "role" "application"
        , Html.Attributes.attribute "aria-label"
            ("Simulation viewport, "
                ++ String.fromInt (Dict.size model.bodies)
                ++ " bodies. "
                ++ modeLabel model.mode
            )
        ]
        ([ viewBoundsRect model.bounds
         ]
            ++ List.map (viewBody model.selected toMsg) (Dict.values model.bodies)
            ++ viewCursor model
        )


modeLabel : UiMode -> String
modeLabel mode =
    case mode of
        DrawMode ->
            "Draw mode"

        SelectMode ->
            "Select mode"


viewBoundsRect : Bounds -> Svg msg
viewBoundsRect bounds =
    rect
        [ SA.x "0"
        , SA.y "0"
        , SA.width (String.fromFloat bounds.width)
        , SA.height (String.fromFloat bounds.height)
        , SA.fill "none"
        , SA.stroke "#2a2a3a"
        , SA.strokeWidth "2"
        ]
        []


viewBody : Maybe BodyId -> (Msg -> msg) -> Body -> Svg msg
viewBody selected toMsg body =
    let
        isSelected =
            selected == Just body.id

        selectionRing =
            if isSelected then
                [ circle
                    [ SA.cx (String.fromFloat body.pos.x)
                    , SA.cy (String.fromFloat body.pos.y)
                    , SA.r (String.fromFloat (body.radius + 4))
                    , SA.fill "none"
                    , SA.stroke "#ff6b3d"
                    , SA.strokeWidth "2"
                    , SA.strokeDasharray "4 3"
                    , SA.opacity "0.7"
                    ]
                    []
                ]

            else
                []
    in
    g []
        (selectionRing
            ++ [ circle
                    [ SA.cx (String.fromFloat body.pos.x)
                    , SA.cy (String.fromFloat body.pos.y)
                    , SA.r (String.fromFloat body.radius)
                    , SA.fill "#ff6b3d"
                    , SA.opacity
                        (if isSelected then
                            "1"

                         else
                            "0.85"
                        )
                    , Html.Attributes.attribute "tabindex" "0"
                    , Html.Attributes.attribute "role" "button"
                    , Html.Attributes.attribute "aria-label"
                        (body.label
                            ++ " at "
                            ++ String.fromInt (round body.pos.x)
                            ++ ", "
                            ++ String.fromInt (round body.pos.y)
                            ++ (if isSelected then
                                    ", selected"

                                else
                                    ""
                               )
                        )
                    , SE.onClick (toMsg (ClickBody body.id))
                    ]
                    [ Svg.title [] [ text body.label ]
                    ]
               ]
        )


viewCursor : Model -> List (Svg msg)
viewCursor model =
    if model.cursor.visible && model.mode == DrawMode then
        let
            cx =
                String.fromFloat model.cursor.pos.x

            cy =
                String.fromFloat model.cursor.pos.y
        in
        [ circle
            [ SA.cx cx
            , SA.cy cy
            , SA.r "20"
            , SA.fill "none"
            , SA.stroke "#ff6b3d"
            , SA.strokeWidth "1.5"
            , SA.opacity "0.4"
            , SA.strokeDasharray "6 4"
            ]
            []
        , line
            [ SA.x1 cx
            , SA.y1 (String.fromFloat (model.cursor.pos.y - 8))
            , SA.x2 cx
            , SA.y2 (String.fromFloat (model.cursor.pos.y + 8))
            , SA.stroke "#ff6b3d"
            , SA.strokeWidth "1"
            , SA.opacity "0.5"
            ]
            []
        , line
            [ SA.x1 (String.fromFloat (model.cursor.pos.x - 8))
            , SA.y1 cy
            , SA.x2 (String.fromFloat (model.cursor.pos.x + 8))
            , SA.y2 cy
            , SA.stroke "#ff6b3d"
            , SA.strokeWidth "1"
            , SA.opacity "0.5"
            ]
            []
        ]

    else
        []
