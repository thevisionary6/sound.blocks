module View.Controls exposing (viewControls, viewInspector, viewAnnouncement)

import Dict
import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick)
import Model exposing (..)


viewControls : Model -> msg -> msg -> msg -> Html msg
viewControls model toggleRunMsg toggleModeMsg clearMsg =
    div
        [ style "padding" "12px 16px"
        , style "background" "#13131a"
        , style "border-bottom" "1px solid #2a2a3a"
        , style "display" "flex"
        , style "gap" "8px"
        , style "align-items" "center"
        , style "font-size" "13px"
        , attribute "role" "toolbar"
        , attribute "aria-label" "Simulation controls"
        ]
        [ controlButton
            (if model.running then
                "Pause"

             else
                "Play"
            )
            toggleRunMsg
        , controlButton
            (case model.mode of
                DrawMode ->
                    "Mode: Draw"

                SelectMode ->
                    "Mode: Select"
            )
            toggleModeMsg
        , controlButton "Clear" clearMsg
        , span
            [ style "color" "#7a7a8e"
            , style "margin-left" "auto"
            , style "font-family" "monospace"
            , style "font-size" "11px"
            ]
            [ text
                ("Bodies: "
                    ++ String.fromInt (Dict.size model.bodies)
                    ++ "  Step: "
                    ++ String.fromInt model.stepCount
                )
            ]
        ]


controlButton : String -> msg -> Html msg
controlButton label msg =
    button
        [ onClick msg
        , style "padding" "6px 14px"
        , style "background" "#1a1a24"
        , style "color" "#e0e0ec"
        , style "border" "1px solid #2a2a3a"
        , style "border-radius" "6px"
        , style "font-family" "inherit"
        , style "font-size" "12px"
        , style "cursor" "pointer"
        , attribute "aria-label" label
        ]
        [ text label ]


viewInspector : Model -> Html msg
viewInspector model =
    let
        content =
            case model.selected of
                Nothing ->
                    [ span [ style "color" "#7a7a8e" ]
                        [ text "No body selected." ]
                    ]

                Just id ->
                    case Dict.get id model.bodies of
                        Nothing ->
                            [ span [ style "color" "#7a7a8e" ]
                                [ text "Selected body no longer exists." ]
                            ]

                        Just body ->
                            [ div [] [ text ("Name: " ++ body.label) ]
                            , div []
                                [ text
                                    ("Position: "
                                        ++ String.fromInt (round body.pos.x)
                                        ++ ", "
                                        ++ String.fromInt (round body.pos.y)
                                    )
                                ]
                            , div []
                                [ text
                                    ("Velocity: "
                                        ++ String.fromInt (round body.vel.x)
                                        ++ ", "
                                        ++ String.fromInt (round body.vel.y)
                                    )
                                ]
                            , div []
                                [ text
                                    ("Radius: " ++ String.fromInt (round body.radius))
                                ]
                            , div []
                                [ text
                                    ("Mass: " ++ String.fromFloat (toFloat (round (body.mass * 100)) / 100))
                                ]
                            ]
    in
    div
        [ style "padding" "10px 16px"
        , style "background" "#13131a"
        , style "border-top" "1px solid #2a2a3a"
        , style "font-size" "12px"
        , style "font-family" "monospace"
        , style "color" "#e0e0ec"
        , style "min-height" "80px"
        , attribute "role" "region"
        , attribute "aria-label" "Body inspector"
        , attribute "aria-live" "polite"
        ]
        content


viewAnnouncement : String -> Html msg
viewAnnouncement text_ =
    div
        [ style "position" "absolute"
        , style "width" "1px"
        , style "height" "1px"
        , style "overflow" "hidden"
        , style "clip" "rect(0,0,0,0)"
        , attribute "role" "status"
        , attribute "aria-live" "polite"
        , attribute "aria-atomic" "true"
        ]
        [ text text_ ]
