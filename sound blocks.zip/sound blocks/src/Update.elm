module Update exposing (Msg(..), update, subscriptions)

import Browser.Events
import Dict
import Json.Decode as Decode
import Model exposing (..)
import Physics.Step
import Time


type Msg
    = Tick Time.Posix
    | KeyDown String
    | ToggleRun
    | ToggleMode
    | Clear
    | ClickBody BodyId


update : Msg -> Model -> Model
update msg model =
    case msg of
        Tick _ ->
            if model.running then
                { model
                    | bodies = Physics.Step.step model.sim model.bounds model.bodies
                    , stepCount = model.stepCount + 1
                }

            else
                model

        ToggleRun ->
            { model
                | running = not model.running
                , announcement =
                    if model.running then
                        "Paused."

                    else
                        "Running."
            }

        ToggleMode ->
            let
                newMode =
                    case model.mode of
                        DrawMode ->
                            SelectMode

                        SelectMode ->
                            DrawMode
            in
            { model
                | mode = newMode
                , announcement =
                    case newMode of
                        DrawMode ->
                            "Draw mode. Arrow keys move cursor, Enter places a circle."

                        SelectMode ->
                            "Select mode. Tab through bodies, arrow keys nudge selected body."
            }

        Clear ->
            { model
                | bodies = Dict.empty
                , nextId = 1
                , selected = Nothing
                , announcement = "All bodies cleared."
            }

        ClickBody id ->
            { model
                | selected = Just id
                , mode = SelectMode
                , announcement =
                    case Dict.get id model.bodies of
                        Just body ->
                            body.label ++ " selected."

                        Nothing ->
                            "Body selected."
            }

        KeyDown key ->
            handleKey key model


handleKey : String -> Model -> Model
handleKey key model =
    case model.mode of
        DrawMode ->
            handleDrawKey key model

        SelectMode ->
            handleSelectKey key model


handleDrawKey : String -> Model -> Model
handleDrawKey key model =
    let
        step =
            20

        cursor =
            model.cursor

        bounds =
            model.bounds
    in
    case key of
        "ArrowUp" ->
            { model
                | cursor =
                    { cursor
                        | pos =
                            { x = cursor.pos.x
                            , y = max 20 (cursor.pos.y - step)
                            }
                    }
            }

        "ArrowDown" ->
            { model
                | cursor =
                    { cursor
                        | pos =
                            { x = cursor.pos.x
                            , y = min (bounds.height - 20) (cursor.pos.y + step)
                            }
                    }
            }

        "ArrowLeft" ->
            { model
                | cursor =
                    { cursor
                        | pos =
                            { x = max 20 (cursor.pos.x - step)
                            , y = cursor.pos.y
                            }
                    }
            }

        "ArrowRight" ->
            { model
                | cursor =
                    { cursor
                        | pos =
                            { x = min (bounds.width - 20) (cursor.pos.x + step)
                            , y = cursor.pos.y
                            }
                    }
            }

        "Enter" ->
            let
                newBody =
                    makeBody model.nextId cursor.pos 20

                newBodies =
                    Dict.insert model.nextId newBody model.bodies
            in
            { model
                | bodies = newBodies
                , nextId = model.nextId + 1
                , announcement =
                    newBody.label
                        ++ " placed at "
                        ++ String.fromInt (round cursor.pos.x)
                        ++ ", "
                        ++ String.fromInt (round cursor.pos.y)
                        ++ ". "
                        ++ String.fromInt (Dict.size newBodies)
                        ++ " bodies total."
            }

        " " ->
            -- Space also places
            handleDrawKey "Enter" model

        "Tab" ->
            { model
                | mode = SelectMode
                , announcement = "Select mode. Tab through bodies, arrow keys nudge selected body."
            }

        "p" ->
            update ToggleRun model

        "r" ->
            update ToggleRun model

        _ ->
            model


handleSelectKey : String -> Model -> Model
handleSelectKey key model =
    case key of
        "Tab" ->
            let
                bodyIds =
                    Dict.keys model.bodies

                nextSelected =
                    case model.selected of
                        Nothing ->
                            List.head bodyIds

                        Just current ->
                            let
                                afterCurrent =
                                    List.filter (\id -> id > current) bodyIds
                            in
                            case afterCurrent of
                                next :: _ ->
                                    Just next

                                [] ->
                                    List.head bodyIds
            in
            { model
                | selected = nextSelected
                , announcement =
                    case nextSelected of
                        Just id ->
                            case Dict.get id model.bodies of
                                Just body ->
                                    body.label
                                        ++ " at "
                                        ++ String.fromInt (round body.pos.x)
                                        ++ ", "
                                        ++ String.fromInt (round body.pos.y)

                                Nothing ->
                                    "Selected body " ++ String.fromInt id

                        Nothing ->
                            "No bodies to select."
            }

        "ArrowUp" ->
            nudgeSelected { x = 0, y = -15 } model

        "ArrowDown" ->
            nudgeSelected { x = 0, y = 15 } model

        "ArrowLeft" ->
            nudgeSelected { x = -15, y = 0 } model

        "ArrowRight" ->
            nudgeSelected { x = 15, y = 0 } model

        "Delete" ->
            case model.selected of
                Just id ->
                    let
                        bodyName =
                            Dict.get id model.bodies
                                |> Maybe.map .label
                                |> Maybe.withDefault ("Body " ++ String.fromInt id)

                        newBodies =
                            Dict.remove id model.bodies
                    in
                    { model
                        | bodies = newBodies
                        , selected = Nothing
                        , announcement = bodyName ++ " deleted. " ++ String.fromInt (Dict.size newBodies) ++ " bodies remaining."
                    }

                Nothing ->
                    model

        "Backspace" ->
            handleSelectKey "Delete" model

        "Escape" ->
            { model
                | mode = DrawMode
                , selected = Nothing
                , announcement = "Draw mode. Arrow keys move cursor, Enter places a circle."
            }

        "d" ->
            { model
                | mode = DrawMode
                , announcement = "Draw mode."
            }

        "p" ->
            update ToggleRun model

        "r" ->
            update ToggleRun model

        _ ->
            model


nudgeSelected : Vec2 -> Model -> Model
nudgeSelected impulse model =
    case model.selected of
        Just id ->
            let
                newBodies =
                    Dict.update id
                        (Maybe.map
                            (\body ->
                                { body
                                    | vel =
                                        { x = body.vel.x + impulse.x * 10
                                        , y = body.vel.y + impulse.y * 10
                                        }
                                }
                            )
                        )
                        model.bodies
            in
            { model | bodies = newBodies }

        Nothing ->
            { model | announcement = "No body selected to nudge." }


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        [ if model.running then
            Time.every (1000 / toFloat model.sim.tickRateHz) Tick

          else
            Sub.none
        , Browser.Events.onKeyDown
            (Decode.field "key" Decode.string
                |> Decode.map KeyDown
            )
        ]
