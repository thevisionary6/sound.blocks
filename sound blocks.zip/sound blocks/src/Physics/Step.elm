module Physics.Step exposing (step)

import Dict exposing (Dict)
import Model exposing (..)


step : SimConfig -> Bounds -> Dict BodyId Body -> Dict BodyId Body
step config bounds bodies =
    bodies
        |> Dict.map (\_ b -> integrate config b)
        |> Dict.map (\_ b -> boundaryBounce bounds b)
        |> resolveAllCollisions


integrate : SimConfig -> Body -> Body
integrate config body =
    let
        dt =
            1.0 / toFloat config.tickRateHz

        newVel =
            { x = (body.vel.x + config.gravity.x * dt) * config.damping
            , y = (body.vel.y + config.gravity.y * dt) * config.damping
            }

        newPos =
            { x = body.pos.x + newVel.x * dt
            , y = body.pos.y + newVel.y * dt
            }
    in
    { body | pos = newPos, vel = newVel }


boundaryBounce : Bounds -> Body -> Body
boundaryBounce bounds body =
    let
        r =
            body.radius

        ( px, vx ) =
            clampAxis r bounds.width body.pos.x body.vel.x

        ( py, vy ) =
            clampAxis r bounds.height body.pos.y body.vel.y
    in
    { body
        | pos = { x = px, y = py }
        , vel = { x = vx, y = vy }
    }


clampAxis : Float -> Float -> Float -> Float -> ( Float, Float )
clampAxis radius limit pos vel =
    if pos - radius < 0 then
        ( radius, abs vel * 0.7 )

    else if pos + radius > limit then
        ( limit - radius, -(abs vel) * 0.7 )

    else
        ( pos, vel )


resolveAllCollisions : Dict BodyId Body -> Dict BodyId Body
resolveAllCollisions bodies =
    let
        bodyList =
            Dict.values bodies

        pairs =
            makePairs bodyList
    in
    List.foldl resolvePair bodies pairs


makePairs : List Body -> List ( BodyId, BodyId )
makePairs bodies =
    case bodies of
        [] ->
            []

        b :: rest ->
            List.map (\other -> ( b.id, other.id )) rest
                ++ makePairs rest


resolvePair : ( BodyId, BodyId ) -> Dict BodyId Body -> Dict BodyId Body
resolvePair ( idA, idB ) bodies =
    case ( Dict.get idA bodies, Dict.get idB bodies ) of
        ( Just a, Just b ) ->
            let
                dx =
                    b.pos.x - a.pos.x

                dy =
                    b.pos.y - a.pos.y

                dist =
                    sqrt (dx * dx + dy * dy)

                minDist =
                    a.radius + b.radius
            in
            if dist < minDist && dist > 0.001 then
                let
                    nx =
                        dx / dist

                    ny =
                        dy / dist

                    overlap =
                        minDist - dist

                    totalMass =
                        a.mass + b.mass

                    -- Separate bodies
                    sepA =
                        overlap * (b.mass / totalMass)

                    sepB =
                        overlap * (a.mass / totalMass)

                    newPosA =
                        { x = a.pos.x - nx * sepA
                        , y = a.pos.y - ny * sepA
                        }

                    newPosB =
                        { x = b.pos.x + nx * sepB
                        , y = b.pos.y + ny * sepB
                        }

                    -- Impulse
                    dvx =
                        a.vel.x - b.vel.x

                    dvy =
                        a.vel.y - b.vel.y

                    dvn =
                        dvx * nx + dvy * ny
                in
                if dvn > 0 then
                    -- Moving apart, just separate
                    bodies
                        |> Dict.insert idA { a | pos = newPosA }
                        |> Dict.insert idB { b | pos = newPosB }

                else
                    let
                        restitution =
                            min a.restitution b.restitution

                        j =
                            -(1 + restitution) * dvn / (1 / a.mass + 1 / b.mass)

                        newVelA =
                            { x = a.vel.x + j * nx / a.mass
                            , y = a.vel.y + j * ny / a.mass
                            }

                        newVelB =
                            { x = b.vel.x - j * nx / b.mass
                            , y = b.vel.y - j * ny / b.mass
                            }
                    in
                    bodies
                        |> Dict.insert idA { a | pos = newPosA, vel = newVelA }
                        |> Dict.insert idB { b | pos = newPosB, vel = newVelB }

            else
                bodies

        _ ->
            bodies
